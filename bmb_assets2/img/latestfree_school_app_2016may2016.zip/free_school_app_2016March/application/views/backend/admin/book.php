<style type="text/css">
<!--
.style2 {color: #990000}
.style3 {font-size: 18px}
-->
</style>
<p align="center" class="style3"><strong>Disabled in Basic Version</strong> (+2348033527716 for watsapp discussion and video demo) </p>
<p align="center" class="style3"><strong><a href="www.optimumlinkup.com.ng" target="_blank" class="style2"><u>Upgrade</u></a> to full version for just 60$ only. <u>100% Source Code</u> <a href="www.optimumlinkup.com.ng" target="_blank"><u><span class="style2">www.Optimum Linkup.com.ng</span> </u></a></strong></p>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<div align="center">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="4BKA5ZHWXARDU">
</div>
<table>
<tr>
  <td>&nbsp;</td>
</tr><tr>
  <td>&nbsp;</td>
</tr>
</table>
</form>
<p><img src="uploads/images/admin/library_admin.PNG" width="1044" height="390" /></p>
